import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import re

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node catalog table
catalogtable_node1 = glueContext.create_dynamic_frame.from_catalog(
    database="moondb",
    table_name="customer_landing2",
    transformation_ctx="catalogtable_node1",
)

# Script generated for node Filter
Filter_node1685424941296 = Filter.apply(
    frame=catalogtable_node1,
    f=lambda row: (not (row["sharewithresearchasofdate"] == 0)),
    transformation_ctx="Filter_node1685424941296",
)

# Script generated for node S3 bucket
S3bucket_node3 = glueContext.getSink(
    path="s3://moon-lake-house/customer/trusted/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="S3bucket_node3",
)
S3bucket_node3.setCatalogInfo(
    catalogDatabase="moondb", catalogTableName="customer_trusted"
)
S3bucket_node3.setFormat("json")
S3bucket_node3.writeFrame(Filter_node1685424941296)
job.commit()
