import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node Amazon S3
AmazonS3_node1685531859609 = glueContext.create_dynamic_frame.from_catalog(
    database="moondb",
    table_name="customer_curated",
    transformation_ctx="AmazonS3_node1685531859609",
)

# Script generated for node Amazon S3
AmazonS3_node1685531830712 = glueContext.create_dynamic_frame.from_catalog(
    database="moondb",
    table_name="step_trainer_landing",
    transformation_ctx="AmazonS3_node1685531830712",
)

# Script generated for node Renamed keys for Join
RenamedkeysforJoin_node1685541785981 = ApplyMapping.apply(
    frame=AmazonS3_node1685531859609,
    mappings=[
        ("customername", "string", "`(right) customername`", "string"),
        ("email", "string", "`(right) email`", "string"),
        ("phone", "string", "`(right) phone`", "string"),
        ("birthday", "string", "`(right) birthday`", "string"),
        ("serialnumber", "string", "`(right) serialnumber`", "string"),
        ("registrationdate", "long", "`(right) registrationdate`", "long"),
        ("lastupdatedate", "long", "`(right) lastupdatedate`", "long"),
        (
            "sharewithresearchasofdate",
            "long",
            "`(right) sharewithresearchasofdate`",
            "long",
        ),
        (
            "sharewithpublicasofdate",
            "long",
            "`(right) sharewithpublicasofdate`",
            "long",
        ),
        (
            "sharewithfriendsasofdate",
            "long",
            "`(right) sharewithfriendsasofdate`",
            "long",
        ),
    ],
    transformation_ctx="RenamedkeysforJoin_node1685541785981",
)

# Script generated for node Join
Join_node1685523954070 = Join.apply(
    frame1=AmazonS3_node1685531830712,
    frame2=RenamedkeysforJoin_node1685541785981,
    keys1=["serialnumber"],
    keys2=["`(right) serialnumber`"],
    transformation_ctx="Join_node1685523954070",
)

# Script generated for node Drop Fields
DropFields_node1685524685732 = DropFields.apply(
    frame=Join_node1685523954070,
    paths=[
        "`(right) customername`",
        "`(right) email`",
        "`(right) phone`",
        "`(right) birthday`",
        "`(right) serialnumber`",
        "`(right) registrationdate`",
        "`(right) lastupdatedate`",
        "`(right) sharewithresearchasofdate`",
        "`(right) sharewithpublicasofdate`",
        "`(right) sharewithfriendsasofdate`",
    ],
    transformation_ctx="DropFields_node1685524685732",
)

# Script generated for node S3 bucket
S3bucket_node3 = glueContext.write_dynamic_frame.from_options(
    frame=DropFields_node1685524685732,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://moon-lake-house/step_trainer/trusted/",
        "partitionKeys": [],
    },
    transformation_ctx="S3bucket_node3",
)

job.commit()
