import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1685524132045 = glueContext.create_dynamic_frame.from_catalog(
    database="moondb",
    table_name="accelerometer_landing",
    transformation_ctx="AWSGlueDataCatalog_node1685524132045",
)

# Script generated for node AWS Glue Data Catalog
AWSGlueDataCatalog_node1685524151063 = glueContext.create_dynamic_frame.from_catalog(
    database="moondb",
    table_name="customer_trusted",
    transformation_ctx="AWSGlueDataCatalog_node1685524151063",
)

# Script generated for node Join
Join_node1685523954070 = Join.apply(
    frame1=AWSGlueDataCatalog_node1685524132045,
    frame2=AWSGlueDataCatalog_node1685524151063,
    keys1=["user"],
    keys2=["email"],
    transformation_ctx="Join_node1685523954070",
)

# Script generated for node Drop Fields
DropFields_node1685524685732 = DropFields.apply(
    frame=Join_node1685523954070,
    paths=[
        "customername",
        "email",
        "phone",
        "birthday",
        "serialnumber",
        "registrationdate",
        "lastupdatedate",
        "sharewithresearchasofdate",
        "sharewithpublicasofdate",
        "sharewithfriendsasofdate",
    ],
    transformation_ctx="DropFields_node1685524685732",
)

# Script generated for node S3 bucket
S3bucket_node3 = glueContext.getSink(
    path="s3://moon-lake-house/accelerometer/trusted/",
    connection_type="s3",
    updateBehavior="UPDATE_IN_DATABASE",
    partitionKeys=[],
    enableUpdateCatalog=True,
    transformation_ctx="S3bucket_node3",
)
S3bucket_node3.setCatalogInfo(
    catalogDatabase="moondb", catalogTableName="accelerometer_trusted"
)
S3bucket_node3.setFormat("json")
S3bucket_node3.writeFrame(DropFields_node1685524685732)
job.commit()
